'''Makes datasets behave like bundles of submodules.'''

from . import cdc

__all__ = ["cdc"]